-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2018 at 07:13 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deliswift`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_city`
--

CREATE TABLE `app_city` (
  `cityID` bigint(20) NOT NULL,
  `countryCode` varchar(2) NOT NULL,
  `provinceID` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `createdDatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdByUserID` bigint(20) NOT NULL DEFAULT '0',
  `modifiedDatetime` datetime DEFAULT NULL,
  `modifiedByUserID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_city`
--

INSERT INTO `app_city` (`cityID`, `countryCode`, `provinceID`, `title`, `isActive`, `createdDatetime`, `createdByUserID`, `modifiedDatetime`, `modifiedByUserID`) VALUES
(1, 'IN', 1, 'Kolkata', 1, '2018-12-13 18:54:38', 1, '2018-12-20 01:00:08', 1),
(2, 'IN', 1, 'test', 1, '2018-12-13 19:29:31', 1, NULL, 1),
(3, 'IN', 1, 'demo', 1, '2018-12-18 18:39:36', 0, NULL, 0),
(4, 'IN', 1, 'demo212d', 1, '2018-12-18 18:40:08', 0, NULL, 0),
(5, 'IN', 1, 'nagaland', 1, '2018-12-18 18:47:21', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `app_country`
--

CREATE TABLE `app_country` (
  `countryID` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `countryCode` varchar(2) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `createdDatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdByUserID` bigint(20) NOT NULL DEFAULT '0',
  `modifiedDatetime` datetime DEFAULT NULL,
  `modifiedByUserID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_country`
--

INSERT INTO `app_country` (`countryID`, `title`, `countryCode`, `isActive`, `createdDatetime`, `createdByUserID`, `modifiedDatetime`, `modifiedByUserID`) VALUES
(1, 'India', 'IN', 1, '2018-12-13 18:44:26', 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `app_province`
--

CREATE TABLE `app_province` (
  `provinceID` bigint(20) NOT NULL,
  `countryCode` varchar(2) NOT NULL,
  `title` varchar(100) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `createdDatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdByUserID` bigint(20) NOT NULL DEFAULT '0',
  `modifiedDatetime` datetime DEFAULT NULL,
  `modifiedByUserID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_province`
--

INSERT INTO `app_province` (`provinceID`, `countryCode`, `title`, `isActive`, `createdDatetime`, `createdByUserID`, `modifiedDatetime`, `modifiedByUserID`) VALUES
(1, 'IN', 'West Bengal', 1, '2018-12-13 18:51:20', 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `app_users`
--

CREATE TABLE `app_users` (
  `userID` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `userType` varchar(20) NOT NULL,
  `isActive` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_users`
--

INSERT INTO `app_users` (`userID`, `name`, `username`, `password`, `userType`, `isActive`) VALUES
(1, 'Test Admin', 'admin', 'cc03e747a6afbbcbf8be7668acfebee5', 'superuser', 1);

-- --------------------------------------------------------

--
-- Table structure for table `res_delivery_location`
--

CREATE TABLE `res_delivery_location` (
  `deliveryLocationID` bigint(20) NOT NULL,
  `countryCode` varchar(2) NOT NULL,
  `provinceID` bigint(20) NOT NULL,
  `cityID` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `createdDatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdByUserID` bigint(20) NOT NULL DEFAULT '0',
  `modifiedDatetime` datetime DEFAULT NULL,
  `modifiedByUserID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_delivery_location`
--

INSERT INTO `res_delivery_location` (`deliveryLocationID`, `countryCode`, `provinceID`, `cityID`, `title`, `isActive`, `createdDatetime`, `createdByUserID`, `modifiedDatetime`, `modifiedByUserID`) VALUES
(1, 'IN', 1, 1, 'Ruby, Kalikapur', 1, '2018-12-13 19:02:28', 1, NULL, 0),
(2, 'IN', 1, 1, 'Mukandupur, Kalikapur', 1, '2018-12-13 19:02:28', 1, NULL, 0),
(3, 'IN', 1, 1, 'hkjb', 1, '2018-12-20 15:47:10', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `res_menu_course_type`
--

CREATE TABLE `res_menu_course_type` (
  `menuCourseTypeID` bigint(20) NOT NULL,
  `type` varchar(100) NOT NULL,
  `createdDatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdByUserID` bigint(20) NOT NULL DEFAULT '0',
  `modifiedDatetime` datetime DEFAULT NULL,
  `modifiedByUserID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_menu_course_type`
--

INSERT INTO `res_menu_course_type` (`menuCourseTypeID`, `type`, `createdDatetime`, `createdByUserID`, `modifiedDatetime`, `modifiedByUserID`) VALUES
(1, 'starter', '2018-12-12 18:13:26', 1, NULL, 0),
(2, 'combo', '2018-12-12 18:13:26', 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `res_menu_item`
--

CREATE TABLE `res_menu_item` (
  `menuItemID` bigint(20) NOT NULL,
  `menuItemName` varchar(100) NOT NULL,
  `courseType` bigint(20) NOT NULL,
  `isVeg` tinyint(1) NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdDatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdByUserID` bigint(20) NOT NULL DEFAULT '0',
  `modifiedDatetime` datetime DEFAULT NULL,
  `modifiedByUserID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_menu_item`
--

INSERT INTO `res_menu_item` (`menuItemID`, `menuItemName`, `courseType`, `isVeg`, `isActive`, `createdDatetime`, `createdByUserID`, `modifiedDatetime`, `modifiedByUserID`) VALUES
(3, 'gte hsdf ', 1, 1, 1, '2018-12-12 19:17:45', 1, '2018-12-13 23:14:38', 1),
(5, 'fhgj', 1, 0, 1, '2018-12-13 17:44:26', 1, '2018-12-13 23:18:02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `res_restaurants`
--

CREATE TABLE `res_restaurants` (
  `restaurantID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `imagePath` varchar(255) DEFAULT NULL,
  `contactName` varchar(100) DEFAULT NULL,
  `contactPhone` varchar(15) DEFAULT NULL,
  `contactMobile` varchar(15) DEFAULT NULL,
  `avgCostAmount` int(11) DEFAULT NULL,
  `avgCostHeadCount` int(11) DEFAULT NULL,
  `avgCostInfo` text,
  `isCartAccept` tinyint(1) NOT NULL DEFAULT '0',
  `isHomeDelivery` tinyint(1) NOT NULL DEFAULT '1',
  `bestKnownFor` varchar(150) DEFAULT NULL,
  `countryCode` varchar(2) NOT NULL,
  `provinceID` int(11) NOT NULL,
  `cityID` int(11) NOT NULL,
  `deliveryLocationID` int(11) NOT NULL,
  `contactAddress` varchar(255) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isClosed` tinyint(1) DEFAULT '0',
  `createdDatetime` timestamp NULL DEFAULT NULL,
  `createdByUserID` int(11) NOT NULL,
  `modifiedDatetime` timestamp NULL DEFAULT NULL,
  `modifiedByUserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_restaurants`
--

INSERT INTO `res_restaurants` (`restaurantID`, `name`, `description`, `imagePath`, `contactName`, `contactPhone`, `contactMobile`, `avgCostAmount`, `avgCostHeadCount`, `avgCostInfo`, `isCartAccept`, `isHomeDelivery`, `bestKnownFor`, `countryCode`, `provinceID`, `cityID`, `deliveryLocationID`, `contactAddress`, `isActive`, `isClosed`, `createdDatetime`, `createdByUserID`, `modifiedDatetime`, `modifiedByUserID`) VALUES
(1, 'ITC Kolkata', 'kolkata based hotels', '/restaurant/itc.png', 'Bedh Prakash', '0343590406', '9874521365', 900, 2, 'test cost info', 1, 1, 'Known for kababs', 'IN', 1, 1, 1, 'science city', 1, 0, NULL, 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_city`
--
ALTER TABLE `app_city`
  ADD PRIMARY KEY (`cityID`),
  ADD UNIQUE KEY `countryCode_province_title` (`countryCode`,`provinceID`,`title`);

--
-- Indexes for table `app_country`
--
ALTER TABLE `app_country`
  ADD PRIMARY KEY (`countryID`),
  ADD UNIQUE KEY `countryCode` (`countryCode`);

--
-- Indexes for table `app_province`
--
ALTER TABLE `app_province`
  ADD PRIMARY KEY (`provinceID`),
  ADD UNIQUE KEY `countryCode_title` (`countryCode`,`title`);

--
-- Indexes for table `app_users`
--
ALTER TABLE `app_users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `res_delivery_location`
--
ALTER TABLE `res_delivery_location`
  ADD PRIMARY KEY (`deliveryLocationID`),
  ADD UNIQUE KEY `countryCode_province_city_title` (`countryCode`,`provinceID`,`cityID`,`title`);

--
-- Indexes for table `res_menu_course_type`
--
ALTER TABLE `res_menu_course_type`
  ADD PRIMARY KEY (`menuCourseTypeID`);

--
-- Indexes for table `res_menu_item`
--
ALTER TABLE `res_menu_item`
  ADD PRIMARY KEY (`menuItemID`),
  ADD UNIQUE KEY `menuItemName` (`menuItemName`);

--
-- Indexes for table `res_restaurants`
--
ALTER TABLE `res_restaurants`
  ADD PRIMARY KEY (`restaurantID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_city`
--
ALTER TABLE `app_city`
  MODIFY `cityID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `app_country`
--
ALTER TABLE `app_country`
  MODIFY `countryID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `app_province`
--
ALTER TABLE `app_province`
  MODIFY `provinceID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `app_users`
--
ALTER TABLE `app_users`
  MODIFY `userID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `res_delivery_location`
--
ALTER TABLE `res_delivery_location`
  MODIFY `deliveryLocationID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `res_menu_course_type`
--
ALTER TABLE `res_menu_course_type`
  MODIFY `menuCourseTypeID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `res_menu_item`
--
ALTER TABLE `res_menu_item`
  MODIFY `menuItemID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `res_restaurants`
--
ALTER TABLE `res_restaurants`
  MODIFY `restaurantID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
